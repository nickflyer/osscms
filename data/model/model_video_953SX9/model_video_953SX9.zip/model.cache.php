<?php

if(!defined('IN_SUPESITE')) exit('Access Denied');

/** SupeSite Dump
 * Version: SupeSite 7.0
 * Charset: utf-8
 * Time: 
 * From: 开源中国OSS社区 (http://www.joydou.com)
 * 
 * SupeSite: http://www.supesite.com
 * Please visit our website for latest news about SupeSite
 * --------------------------------------------------------*/


$cacheinfo = Array ('info' => Array ('version' => '7.0','charset' => 'utf-8'),'models' => Array ('modelname' => 'video','modelalias' => '影视','allowpost' => 1,'allowguest' => 0,'allowgrade' => 1,'allowcomment' => 1,'allowrate' => 1,'allowguestsearch' => 1,'allowfeed' => 1,'searchinterval' => 30,'allowguestdownload' => 1,'downloadinterval' => 30,'allowfilter' => 0,'listperpage' => 20,'seokeywords' => '','seodescription' => '','thumbsize' => '400,300','tpl' => '','fielddefault' => ''),'columns' => Array (),'categories' => Array ());

?>